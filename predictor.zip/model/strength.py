# model/strength.py — v1.1
"""
Calcula la fuerza ofensiva y defensiva de un equipo.

Cambios v1.1:
  - Nueva fórmula de lambda normalizada por promedio de liga.
    attack_strength = goles_anotados / avg_liga
    defense_strength = goles_recibidos / avg_liga
    Esto elimina los valores explosivos y el clamp artificial.

  - Separado en local y visitante (Mejora 2 del PDF).
    attack_home, attack_away, defense_home, defense_away.

  - Eliminado el uso de HOME_ADVANTAGE en el historial (Bug 3).
    Ya no se divide el peso por HOME_ADVANTAGE.
    La ventaja local se aplica solo en monte_carlo.py.

  - Redondeo interno eliminado (Bug 2).
    Los valores internos son floats completos.
    El redondeo se hace solo al mostrar en el reporte.
"""
import math
from datetime import date, datetime
from config import (DECAY_RATE, MAX_MONTHS_HISTORY,
                    LEAGUE_AVG_GOALS)
from model.context import get_all_weights, get_competition_weight


def time_decay(match_date_str: str) -> float:
    """Partidos más recientes pesan más."""
    try:
        match_date = datetime.strptime(match_date_str, "%Y-%m-%d").date()
    except ValueError:
        return 0.5
    months_ago = (date.today() - match_date).days / 30
    return math.exp(-DECAY_RATE * months_ago)


def is_too_old(match_date_str: str) -> bool:
    """Descarta partidos más viejos que MAX_MONTHS_HISTORY."""
    try:
        match_date = datetime.strptime(match_date_str, "%Y-%m-%d").date()
    except ValueError:
        return True
    months_ago = (date.today() - match_date).days / 30
    return months_ago > MAX_MONTHS_HISTORY


def _get_league_avg(competition: str) -> float:
    """
    Devuelve el promedio de goles por equipo por partido
    de la competición. Usado para normalizar los lambdas.
    """
    comp_lower = competition.lower()
    for key, avg in LEAGUE_AVG_GOALS.items():
        if key.lower() in comp_lower:
            return avg
    return LEAGUE_AVG_GOALS["default"]


def calcular_lambda(matches: list[dict], team_name: str,
                    verbose: bool = False) -> dict:
    """
    Calcula las fuerzas del equipo usando la fórmula normalizada.

    Fórmula (Dixon & Coles, adaptada):
      attack_strength  = avg(goles_anotados / avg_liga)  ponderado
      defense_strength = avg(goles_recibidos / avg_liga) ponderado

    Separado en local y visitante para eliminar el multiplicador
    artificial de HOME_ADVANTAGE del historial.

    Ponderación de cada partido:
      w = time_decay × w_comp × w_stakes × w_lineup
      (SIN dividir por HOME_ADVANTAGE — Bug 3 corregido)
    """
    # Acumuladores separados por sede
    # Local
    ataque_local_num   = 0.0
    ataque_local_den   = 0.0
    defensa_local_num  = 0.0
    defensa_local_den  = 0.0
    # Visitante
    ataque_visit_num   = 0.0
    ataque_visit_den   = 0.0
    defensa_visit_num  = 0.0
    defensa_visit_den  = 0.0

    partidos_usados = 0
    desglose = []

    for m in matches:
        if is_too_old(m["date"]):
            continue

        w_time = time_decay(m["date"])
        pesos  = get_all_weights(m)
        # FIX Bug 2: no redondear w internamente
        w = w_time * pesos["w_combined"]

        es_local = m["team_home"] == team_name
        comp     = m.get("competition", "Unknown")
        avg_liga = _get_league_avg(comp)

        if es_local:
            gf = m.get("goals_home", 0) or 0
            gc = m.get("goals_away", 0) or 0
            # Normalizar por promedio de liga
            ataque_local_num  += (gf / avg_liga) * w
            ataque_local_den  += w
            defensa_local_num += (gc / avg_liga) * w
            defensa_local_den += w
        else:
            gf = m.get("goals_away", 0) or 0
            gc = m.get("goals_home", 0) or 0
            ataque_visit_num  += (gf / avg_liga) * w
            ataque_visit_den  += w
            defensa_visit_num += (gc / avg_liga) * w
            defensa_visit_den += w

        partidos_usados += 1

        if verbose:
            rival = m["team_away"] if es_local else m["team_home"]
            desglose.append({
                "fecha":    m["date"],
                "rival":    rival,
                "goles":    f"{gf}-{gc}",
                "sede":     "L" if es_local else "V",
                "comp":     comp[:25],
                "avg_liga": avg_liga,
                "w_time":   w_time,           # sin redondear internamente
                "w_comp":   pesos["w_comp"],
                "w_stakes": pesos["w_stakes"],
                "w_lineup": pesos["w_lineup"],
                "w_total":  w,                # sin redondear
            })

    if partidos_usados == 0:
        raise ValueError(
            f"Sin datos válidos para '{team_name}'. "
            f"Verificá el nombre del equipo."
        )

    # Calcular strengths (sin redondear — Bug 2 corregido)
    # Si no hay partidos como local o visitante, usar el promedio global
    def _safe_div(num, den, fallback=1.0):
        return num / den if den > 0 else fallback

    attack_home   = _safe_div(ataque_local_num,  ataque_local_den)
    attack_away   = _safe_div(ataque_visit_num,  ataque_visit_den)
    defense_home  = _safe_div(defensa_local_num, defensa_local_den)
    defense_away  = _safe_div(defensa_visit_num, defensa_visit_den)

    # Fallback: si no hay suficientes partidos de una condición,
    # usar el promedio de ambas condiciones
    total_ataque_num = ataque_local_num + ataque_visit_num
    total_ataque_den = ataque_local_den + ataque_visit_den
    total_defensa_num = defensa_local_num + defensa_visit_num
    total_defensa_den = defensa_local_den + defensa_visit_den

    attack_global  = _safe_div(total_ataque_num,  total_ataque_den)
    defense_global = _safe_div(total_defensa_num, total_defensa_den)

    # Si hay menos de 3 partidos en una condición, usar el global
    partidos_local  = round(ataque_local_den  / 0.5) if ataque_local_den  > 0 else 0
    partidos_visita = round(ataque_visit_den  / 0.5) if ataque_visit_den  > 0 else 0

    if partidos_local < 3:
        attack_home  = attack_global
        defense_home = defense_global
    if partidos_visita < 3:
        attack_away  = attack_global
        defense_away = defense_global

    resultado = {
        "team":            team_name,
        # Valores sin redondear internamente (Bug 2 corregido)
        "attack_home":     attack_home,
        "attack_away":     attack_away,
        "defense_home":    defense_home,
        "defense_away":    defense_away,
        "attack_global":   attack_global,
        "defense_global":  defense_global,
        # Mantener lambda_ataque y lambda_defensa como alias globales
        # para compatibilidad con app.py y analysis_agent.py
        "lambda_ataque":   attack_global,
        "lambda_defensa":  defense_global,
        "partidos_usados": partidos_usados,
    }

    if verbose:
        resultado["desglose"] = desglose

    return resultado
