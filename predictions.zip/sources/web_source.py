# sources/web_source.py
import httpx
from bs4 import BeautifulSoup
from googlesearch import search

HEADERS = {
    "User-Agent": ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                   "AppleWebKit/537.36 (KHTML, like Gecko) "
                   "Chrome/124.0.0.0 Safari/537.36")
}

def get_page_text(url: str, max_chars: int = 4000) -> str:
    try:
        resp = httpx.get(url, headers=HEADERS, timeout=12, follow_redirects=True)
        resp.raise_for_status()
    except Exception:
        return ""

    soup = BeautifulSoup(resp.text, "html.parser")
    for tag in soup(["script", "style", "nav", "footer", "header", "aside"]):
        tag.decompose()
    return soup.get_text(separator="\n", strip=True)[:max_chars]

def search_web(query: str, n: int = 3) -> list[str]:
    try:
        return list(search(query, num_results=n, lang="es", sleep_interval=1))
    except Exception:
        return []

def fetch_multiple(urls: list[str], max_chars: int = 3000) -> str:
    textos = [get_page_text(u, max_chars) for u in urls]
    return "\n\n--- FUENTE ---\n\n".join([t for t in textos if t])

def get_match_news(query: str, n_urls: int = 3) -> str:
    urls = search_web(query, n=n_urls)
    return fetch_multiple(urls) if urls else ""